// export const BASE_URL = "http://192.168.1.239:3014"

// export const BASE_URL = "http://192.168.1.33:3014"
// export const BASE_URL = "https://ssvwsoci.synergicapi.in" //Development
// export const BASE_URL = "http://192.168.224.1:3014";


// export const BASE_URL = "http://202.21.38.178:3014"
export const BASE_URL = "http://192.168.1.33:3014"

// export const BASE_URL = "https://ssvwsadmin.opentech4u.co.in" //Production
