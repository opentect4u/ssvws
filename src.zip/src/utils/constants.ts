export const CONSTANTS = {
    helplineNumeber: "(+91) 6290486130"
}