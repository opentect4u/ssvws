import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const NoInternetScreen = () => {
    return (
        <View>
            <Text>NoInternetScreen</Text>
        </View>
    )
}

export default NoInternetScreen

const styles = StyleSheet.create({})